from typing_extensions import List, TypedDict, Optional,Dict,Annotated
from .pydantic_models import MedicalExtractionSchema, DD_Structure, Test_Structure
class AgentState(TypedDict):
    Patient_Case : str
    Tool_Redirect : bool 
    Diagnosis : Dict
    likliehood : float
    DD_List : List
    Tests : List[Test_Structure]
    Final_dd_list : List[DD_Structure]
    Disease_Stored_Info : List[str]
    Patient_strucutred_info : MedicalExtractionSchema
    Results : List[str]
