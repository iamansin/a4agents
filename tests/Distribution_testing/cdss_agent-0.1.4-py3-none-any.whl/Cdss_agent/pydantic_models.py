from pydantic import BaseModel, Field, validator
from typing_extensions import List, Dict, Union, Tuple, Optional, Any


class ChiefComplaintItem(BaseModel):
    description: str = Field(..., description="Description of the chief complaint")
    duration: Optional[str] = Field(None, description="Duration of the complaint if mentioned")

class HistoryItem(BaseModel):
    condition: str = Field(..., description="The medical condition or symptom")
    onset: Optional[str] = Field(None, description="When the condition began")
    duration: Optional[str] = Field(None, description="How long the condition has persisted")

class MedicationItem(BaseModel):
    name: str = Field(..., description="Name of the medication")
    dosage: Optional[str] = Field(None, description="Dosage information if available")

class AllergyItem(BaseModel):
    allergen: str = Field(..., description="The substance causing the allergic reaction")
    reaction: Optional[str] = Field(None, description="Description of the allergic reaction")

class SystemReviewItem(BaseModel):
    system_name: str = Field(..., description="Name of the body system")
    findings: List[str] = Field(default_factory=list, description="List of symptoms or findings related to this system")

class MedicalExtractionSchema(BaseModel):
    """Complete schema for extracted medical information."""
    patient_demographics: Union[Dict,None] = Field(..., description="Basic patient information as key:value pair, if there is no information about the patient you MUST return None")
    chief_complaints: List[ChiefComplaintItem] = Field(..., description="Primary reason(s) for the visit")
    present_illness_history: List[HistoryItem] = Field(..., description="Details about the current illness")
    past_medical_history: Optional[List[HistoryItem]] = Field(default_factory=list, description="Previous medical conditions")
    family_history: Optional[List[HistoryItem]] = Field(default_factory=list, description="Relevant family medical history")
    social_history: Dict | None = Field(default_factory=dict, description="Lifestyle factors like smoking, alcohol use")
    medications: Optional[List[MedicationItem]] = Field(default_factory=list, description="Current medications")
    allergies: Optional[List[AllergyItem]] = Field(default_factory=list, description="Known allergies")
    review_of_systems: Optional[List[SystemReviewItem]] = Field(default_factory=list, description="Systematic review of body systems")

    @validator("patient_demographics", "social_history", pre=True)
    def handle_invalid_dict_values(cls, value):
        # Handle empty strings, "unknown", empty dicts, and other falsy values
        if not value or (isinstance(value, str) and value.lower() in ["unknown", "none", ""]):
            return None
        # Handle empty dictionaries
        if isinstance(value, dict) and not value:
            return None
        return value


class DiagnosisProbabilityTuple(BaseModel):
    diagnosis: str = Field(..., description="The diagnosis name")
    probability: float = Field(..., description="The probability of the diagnosis")

class Diagnosis_Lead_Structure(BaseModel):
    DD_List: List[DiagnosisProbabilityTuple] = Field(description="This field contains a list of (diagnosis,probability) tuples, here each tuple contains a diagnosis and probability associated with it that represents the likelihood of the occurrence of the particular diagnosis.")

class DD_Structure(BaseModel):
    name : str = Field(description="This field contains the name of the disease.")
    chances : int = Field(description="This field contains the chance of the occurence of that particular disease.")
    rationale : str = Field(description="This field conatins the Thought and elaborated simialrity comparison between the disease and the patients Case.")
    
class DDSchema(BaseModel):
    Diagnosis_List : List[DD_Structure] = Field(description="This field contains a List of DD_Structure which is basically a dict containing the name of the disease ")
    
class Test_Structure(BaseModel):
    disease : str = Field(description="This field contains the name of the disease.")
    test_name :str = Field(description="This field contains the actual medical term for the Test.")
    purpose :str = Field(description="This field contains the purpose of the Provided Test.")
    rationale :str = Field(description="This field contains the detailed rationale of the disease about the compatibility with the patient's case.")
    findings : str = Field(description="This field contains the expected findings of the tests.")
    
class TestSchema(BaseModel):
    Test_List : List[Test_Structure] = Field(description="This field contains a list of Test's having purpose, rationale and findings of each.")
    
# class Differential_strucutre(BaseModel):
#     diagnosis : str = Field(description="This field contains the name of the disease.")
#     rationale : str = Field(description="This field contains a short yet infomative rationale about the particular disease")
#     tests : str = Field(description="This field contains all the tests with names that are for the particular disease. Must mention purpose of the test as well as findings.")
#     medications : str = Field(description="This field contais the medications that might help in the particular disease")
    
# class FinalStructure(BaseModel):
#     response : List[Differential_strucutre] = Field(description="This field contains a list of Differential Diagnosis having detailed information about each.")

class FinalStructure(BaseModel):
    response : str = Field(description="This field contains the CDSS response for the proivded differential Diagnosis")