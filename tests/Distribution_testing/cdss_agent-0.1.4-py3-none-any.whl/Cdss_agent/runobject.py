
import time
import os
import asyncio
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_google_genai import ChatGoogleGenerativeAI
from .cdss_agent import CDSSAgent
from .cdss_agent_state import AgentState
import argparse  # Import the argparse module

load_dotenv()
GOOGLE_API_KEY = os.getenv("GOOGLE_API")
OPENAI_API_KEY = os.getenv("OPENAI_API")
print(GOOGLE_API_KEY, OPENAI_API_KEY)

if not GOOGLE_API_KEY:
    raise ValueError("GOOGLE_API_KEY is not set! Check your .env file.")

gemini_llm = ChatGoogleGenerativeAI(
    model="gemini-2.0-flash",
    api_key =  GOOGLE_API_KEY
)
openai_llm = ChatOpenAI(
    model = "gpt-4o-mini",
    api_key = OPENAI_API_KEY
)

agent = CDSSAgent(model_dict={"main_llm":gemini_llm ,"fall_back_llm": openai_llm })

async def get_response(state : AgentState):
    start_time = time.time()
    print("Invoking agent!!!")
    res = await agent.workflow.ainvoke(state, stream_mode="values")
    print(f"Total Time Taken : {time.time()-start_time}")
    print(res.get("Results"))
    print(f"Total LLM calls : {agent.llm_calls}")
    print(f"successfull llm calls : {agent.successfull_llm_calls}")

def main():
    parser = argparse.ArgumentParser(description="Run the CDSS Agent with a query.")
    parser.add_argument(
        "-q", "--query",
        type=str,
        help="The query to be processed by the agent.",
        required=True  # Make the query argument mandatory
    )
    args = parser.parse_args()
    initial_state : AgentState = {"Tool_Redirect" : False, "Patient_Case" :  args.query}
    asyncio.run(get_response(initial_state))
