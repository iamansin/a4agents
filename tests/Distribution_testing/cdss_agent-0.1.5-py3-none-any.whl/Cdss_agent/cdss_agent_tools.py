from typing import Optional, Dict, Any, List, Type
from pydantic import BaseModel, Field, field_validator

import aiohttp
import asyncio
from bs4 import BeautifulSoup, Tag
import logging
from urllib.parse import quote_plus
import time
import re
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

# Configure logging (keep Python standard logging)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("MedlinePlusScraper")

class MedlinePlusSearchSchema(BaseModel):
    """Input schema for MedlinePlus search tool."""
    disease: str = Field(
        ...,
        description="The disease or medical condition to search for on MedlinePlus"
    )

    @field_validator("disease")
    def validate_disease(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("Disease name cannot be empty")
        if len(v) > 200:
            raise ValueError("Disease name is too long")
        return v.strip()

class MedlinePlusScraperResult(BaseModel):
    """Structured result from MedlinePlus scraper."""
    disease: str = Field(..., description="The disease that was searched for")
    success: bool = Field(..., description="Whether the scraping was successful")
    top_results: List[Dict[str,Dict]] = Field(
        default_factory=list,
        description="Top search results with title and summary"
    )
    error_message: Optional[str] = Field(
        None,
        description="Error message if scraping failed"
    )
    search_url: str = Field(..., description="URL that was queried")
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Additional metadata about the scrape"
    )

class MedlinePlusScraperTool:
    """
    An asynchronous tool for scraping medical information from MedlinePlus search results.

    This tool performs a search for a specific disease or medical condition on the
    National Library of Medicine's MedlinePlus website and extracts structured
    information from the search results page.
    """
    name: str = "medlineplus_scraper"
    description: str = (
        "Search for information about diseases or medical conditions on MedlinePlus. "
        "Input should be a specific disease name (e.g., 'Influenza', 'Type 2 Diabetes'). "
        "Returns structured information from top search results."
    )
    args_schema: Type[BaseModel] = MedlinePlusSearchSchema

    # Tool configuration
    base_url: str = "https://vsearch.nlm.nih.gov/vivisimo/cgi-bin/query-meta"
    max_results: int = 5
    timeout: int = 30
    max_retries: int = 3

    async def _arun(self, disease: str) -> str:
        """
        Asynchronously run the MedlinePlus scraper tool.

        Args:
            disease: The disease or medical condition to search for

        Returns:
            A JSON string containing the structured search results
        """
        start_time: float = time.time()
        encoded_disease: str = quote_plus(disease)
        search_url: str = f"{self.base_url}?v%3aproject=medlineplus&v%3asources=medlineplus-bundle&query={encoded_disease}&"

        logger.info(f"Searching MedlinePlus for: {disease}")

        result: MedlinePlusScraperResult = MedlinePlusScraperResult(
            disease=disease,
            success=False,
            search_url=search_url
        )

        try:
            # Perform the scraping with retry logic
            html_data: str = await self._fetch_data(search_url)
            _dd_list: Dict[str, str] = await self._parse_search_results(html_data) # Assuming _parse_search_results returns a dict now
            co_routines: List[Any] = [self.get_disease_info(_disease, link) for _disease, link in _dd_list.items()]
            search_results: List[Dict] = await asyncio.gather(*co_routines) # Expecting list of dicts

            # Process results
            result.success = True
            result.top_results = search_results[:self.max_results]
            result.metadata = {
                "total_results_found": len(search_results),
                "results_returned": len(result.top_results),
                "processing_time_ms": int((time.time() - start_time) * 1000)
            }

            logger.info(f"Successfully scraped MedlinePlus for '{disease}'. "
                        f"Found {len(search_results)} results.")

        except Exception as e:
            error_msg: str = f"Error scraping MedlinePlus: {str(e)}"
            logger.error(error_msg, exc_info=True)
            result.error_message = error_msg
            result.metadata = {
                "processing_time_ms": int((time.time() - start_time) * 1000),
                "exception_type": type(e).__name__
            }

        # Return the result as a JSON string
        return result.model_dump_json()

    @retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=2, max=10),
    retry=retry_if_exception_type((
        aiohttp.ClientError,
        asyncio.TimeoutError,
        ConnectionError
    )),
    reraise=True)
    async def _fetch_data(self, url: str) -> str:
        """
        Fetch the search results page and parse the content.

        Args:
            url: The URL to fetch

        Returns:
            str: The HTML content as a string
        """
        headers: Dict[str, str] = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        }

        async with aiohttp.ClientSession() as session:
            logger.info(f"Fetching URL: {url}")
            async with session.get(url, headers=headers, timeout=self.timeout) as response:
                if response.status != 200:
                    logger.error(f"HTTP error {response.status}: {response.reason}")
                    raise ValueError(f"HTTP error {response.status}: {response.reason}")

                logger.info(f"Response status: {response.status}, Content-Type: {response.headers.get('Content-Type', 'unknown')}")
                html_content: str = await response.text()

                content_length: int = len(html_content)
                logger.info(f"Received {content_length} bytes of HTML content")

                if not html_content or content_length < 100:
                    raise ValueError("Empty or invalid response received")

                # Check if it's potentially a redirect to a CAPTCHA or error page
                if content_length < 5000 and any(x in html_content.lower() for x in
                                                    ['captcha', 'robot', 'automated', 'detect']):
                    logger.warning("Possible CAPTCHA or bot detection page received")

                return html_content


    async def _parse_search_results(self, html_content: str, for_disease: bool = False, _disease_name: str = "None") -> Dict[str, str]:
        """
        Parse the HTML content of the search results page, extracting data based on context.

        Args:
            html_content: The HTML content to parse
            for_disease: Boolean flag to indicate if parsing a disease-specific article
            _disease_name: Name of the disease (for context, optional)

        Returns:
            Dict[str, str]: A dictionary of parsed results (keys and structure depend on parsing context)
                                    For search results: {article_name: article_link, ...}
                                    For disease article: {"summary": "extracted summary text"} or {} if no summary
        """
        results: Dict[str, str] = {} # Initialize as dict to match return type
        soup: BeautifulSoup = BeautifulSoup(html_content, 'html.parser')

        if for_disease:
            try:
                article = soup.select_one("article")
                if article:
                    topic_summary_div = article.select_one("#topic-summary")
                    if topic_summary_div:
                        ordered_text_content: List[str] = []
                        for element in topic_summary_div.children:
                            if isinstance(element, Tag):  # Standard Python type check
                                tag_name: str = element.name
                                text_content: str = element.get_text(strip=True)
                                if text_content:
                                    ordered_text_content.append(text_content)
                                    if tag_name == 'ul':
                                        # If it's a list, also extract text from each list item <li>
                                        list_items_text: List[str] = [li.get_text(strip=True) for li in element.find_all('li')]
                                        ordered_text_content.extend(list_items_text)

                        results["summary"] = " ".join(ordered_text_content)

                    else:
                        logger.warning("No div with id 'topic-summary' found within the article.")
                        return {}  # Return empty dict for consistency
                else:
                    logger.warning("No <article> tag found in the HTML.")
                    return {} # Return empty dict for consistency

                return results

            except Exception as e:
                raise ValueError(f"Not able to find div.topic_summary: {e}") from e # Raise with original exception as cause


        # Debug logging for page title
        logger.debug(f"Page title: {soup.title.text if soup.title else 'No title found'}")

        # Prioritize parsing from 'ol.results'
        results_list_ol: Optional[BeautifulSoup] = soup.select_one('ol.results') # Corrected type hint

        if results_list_ol:
            logger.info("Found 'ol.results' list, parsing using new logic.")
            result_items = results_list_ol.find_all('li', class_='document source-health-topics')
            logger.info(f"Found {len(result_items)} result items in 'ol.results' list.")

            for item in result_items:

                try:
                    article_name_element = item.select_one('div.document-header').select_one('a')
                    link_element = item.select_one('div.document-footer').select_one('span.url')

                    if article_name_element and link_element:
                        article_name: str = article_name_element.text
                        link: str = link_element.text
                        # print(article_name, link) # Keep print for debugging - consider logger.debug
                        results[article_name] = link
                    else:
                        raise ValueError(f"Could not find article name or link elements in result item: {item.prettify()}") # More descriptive error

                except Exception as e:
                    logger.warning(f"Error processing a result item in 'ol.results': {e}")
                    continue  # Continue to next item even if one fails

            return results # Return even if some items failed, return what we could parse

        return results # Return empty dict if no ol.results found or parsing failed completely


    async def get_disease_info(self, _disease_name: str, url: str) -> Dict[str, Optional[Dict]]:
        """
        Asynchronously retrieves and parses disease-specific information from a given URL.

        Args:
            _disease_name: The name of the disease being processed.
            url: The URL of the disease information page.

        Returns:
            Dict[str, Optional[Dict]]: A dictionary containing the disease name as key and
                                            parsed data (currently summary) as value. Value is None on failure.
        """
        try:
            html_data: str = await self._fetch_data(url)
            data: Optional[Dict] = await self._parse_search_results(html_data, for_disease=True, _disease_name=_disease_name)
            return {_disease_name: data} # Return dictionary directly with parsed data
        except Exception as e:
            logger.error(f"Error in get_disease_info for {_disease_name} at {url}: {e}", exc_info=True)
            return {_disease_name: {"success": False, "error": str(e)}} # Indicate failure in result



    def _run(self, disease: str) -> str:
        """
        Synchronous interface for the tool (required by LangChain).
        This simply runs the async method in an event loop.

        Args:
            disease: The disease to search for

        Returns:
            JSON string with search results
        """
        return asyncio.run(self._arun(disease))