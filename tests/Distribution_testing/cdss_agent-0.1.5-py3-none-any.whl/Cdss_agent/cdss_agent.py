import json
import time
import asyncio
from collections import defaultdict
from langchain.prompts import PromptTemplate
from langgraph.graph import StateGraph, END
from langchain.output_parsers import PydanticOutputParser
from pydantic import BaseModel
from .pydantic_models import MedicalExtractionSchema, Diagnosis_Lead_Structure, DDSchema, DD_Structure, TestSchema, FinalStructure
from .cdss_agent_state import AgentState
from .cdss_agent_prompts import (EXTRACTION_THINKER_PROMPT, DIAGNOSIS_THINKER_PROMPT, DD_PROMPT, TEST_PROMPT, FINAL_PROMPT)
# from tools.Scraper.medline_tool import MedlinePlusScraperTool 
from .cdss_agent_tools import MedlinePlusScraperTool

class CDSSAgent:
    def __init__(self, model_dict, cutoff_probability :float = 0.30):
        self._llm_dict = model_dict
        self.cutoff_probability = 0.30
        self.llm_calls = 0
        self.successfull_llm_calls = 0
        self.workflow = self._create_workflow()
        
    def _create_workflow(self):
        """Create the workflow graph for the CDSS agent."""
        workflow = StateGraph(AgentState)
        # Add nodes
        workflow.add_node("thinker", self.thinker_node)
        workflow.add_node("dd_tool", self.dd_node)
        workflow.add_node("di_tool", self.di_node)
        workflow.add_node("test_tool", self.test_node)
        workflow.add_node("validator", self.validator_node)
        workflow.set_entry_point("thinker")
        # Add edges
        workflow.add_edge("thinker", "dd_tool")
        workflow.add_edge("test_tool", "validator")
        workflow.add_edge("di_tool", "validator")
        workflow.add_edge("validator", END)
        #adding conditional edges
        workflow.add_conditional_edges("dd_tool", self.router_Thinker_node, {
            "di_tool": "di_tool",
            "test_tool" : "test_tool"
        })
        return workflow.compile()
    
    async def generate_structured_response(self, PROMPT :str, pydantic_model :BaseModel,use_openai :bool = False, print_prompt :bool = False, **kwargs):
        """This function takes Prompts, Json_Schema and formating instruction to generate a proper structred response. """
        try:
            self.llm_calls += 1
            parser = PydanticOutputParser(pydantic_object = pydantic_model)
            template = PromptTemplate.from_template(template=PROMPT, partial_variables= {"format_instructions": parser.get_format_instructions()})
            message = template.format(**kwargs)
            if print_prompt:
                print(f"The prompt is: \n {message}")
        except KeyError as ke:
            raise ke
        except Exception as e:
            raise e
        
        if use_openai:
            llm_structured = self._llm_dict["fall_back_llm"].with_structured_output(pydantic_model)
            print("using openai")
        else:
            llm_structured = self._llm_dict["main_llm"].with_structured_output(pydantic_model)
            
        start_time = time.time()
        for attempt in range(1,4):
            try:
                # LOGGER.info(f"Attempt {attempt}: Invoking LLM")
                structured_response = await llm_structured.ainvoke(message)
                if structured_response:
                    print(f"Time Taken to generate the response : {time.time() - start_time}")
                    self.successfull_llm_calls +=1
                    return structured_response
                continue
            except Exception as e:
                raise e
        fall_back_llm = self._llm_dict["fall_back_llm"].with_structured_output(pydantic_model)
        # LOGGER.info("Using Fall Back LLM.")
        try:
            structured_response = await fall_back_llm.ainvoke(message)
            if structured_response:
                # LOGGER.info(f"Recieved result is : {structured_response}")
                self.successfull_llm_calls +=1
                return structured_response
        except Exception as e:
            # LOGGER.error(f"Attempt failed: {str(e)}")
            raise RuntimeError("Failed to get a structured response from the LLM after 3 attempts.")

    
    async def thinker_node(self, state: AgentState):
        """Initial node that processes patient information and structures it for analysis."""
        
        if state["Tool_Redirect"]:
            return state
        
        else:
            try:
                #Extracting information from the description..
                patient_case = state["Patient_Case"]
                response= await self.generate_structured_response(EXTRACTION_THINKER_PROMPT, MedicalExtractionSchema, 
                                                            Case = patient_case)
                state["Patient_strucutred_info"] = response
                #Providing the LLM with extracted user information to get Diagnsis leads..
                diagnosis_leads = await self.generate_structured_response(DIAGNOSIS_THINKER_PROMPT, Diagnosis_Lead_Structure,
                                            patient_demographics = response.patient_demographics, chief_complaints = response.chief_complaints, 
                                            present_illness_history = response.present_illness_history, past_medical_history = response.past_medical_history,
                                            family_history = response.family_history, social_history= response.social_history,
                                            medications = response.medications, allergies = response.allergies,review_of_systems= response.review_of_systems)
                
                # print(f"total dd provided  : {len(diagnosis_leads.DD_List)}")
                state["DD_List"] = diagnosis_leads.DD_List
                return state
        
            except Exception as e:
                raise e
        
        
    async def dd_node(self, state: dict) -> dict: # type hint for state as dict, assuming AgentState is a dict-like structure
        """
        Differential diagnosis node that identifies possible diagnoses based on patient information.

        Optimized for production:
        - Asynchronous scraping for parallel execution.
        - Caching of scraping results to reduce redundant calls and improve speed.
        - Robust error handling with logging.
        - Efficient data processing.
        """
        scraper_tool = MedlinePlusScraperTool() # Initialize scraper tool - consider making this a class member if it's reused

        main_results = {}
        tasks = []
        disease_list = state.get("DD_List", []) # Safely get DD_List, default to empty list if not present

        if not disease_list:
            return state

        for _disease in disease_list:
            diagnosis = _disease.diagnosis # Safe access using .get()
            probability = _disease.probability # Default probability to 0.0 if not present

            if not diagnosis:
                # logger.warning(f"Disease entry missing 'diagnosis' field. Skipping entry: {_disease}")
                continue # Skip to the next disease

            if probability >= self.cutoff_probability:
                # logger.info(f"Now searching for diagnosis: {diagnosis} with probability: {probability}")

                # Check cache first
                # cached_result = self.scraper_cache.get(diagnosis)
                # if cached_result:
                #     pass
                #     # logger.info(f"Cache hit for diagnosis: {diagnosis}. Using cached result.")
                #     # tasks.append(asyncio.to_thread(lambda diag=diagnosis, res=cached_result: res)) # Wrap cached result to mimic async task
                # else:
                    # logger.info(f"Cache miss for diagnosis: {diagnosis}. Scraping from MedlinePlus.")
                    tasks.append(scraper_tool._arun(diagnosis)) # Create _arun task if not in cache
            else:
                # logger.info(f"Disease '{diagnosis}' has probability {probability:.2f} below cutoff ({self.cutoff_probability:.2f}). Removing from consideration.")
                pass

        results = []
        if tasks: # Only gather if there are tasks to run
            try:
                results = await asyncio.gather(*tasks, return_exceptions=True) # Run tasks in parallel
            except Exception as e:
                # logger.error(f"Exception during asyncio.gather: {e}", exc_info=True) # Log full exception info
                raise RuntimeError(f"Error during parallel scraping tasks: {e}") from e # Re-raise with context

        # logger.info(f"Time taken by all scraping tasks: {time_taken:.2f} seconds")
        # logger.info(f"Number of results received from scraping tool: {len(results)}")

        for result_raw in results:
            if isinstance(result_raw, Exception):
                # logger.error(f"Exception in scraping task: {result_raw}", exc_info=True) # Log individual task exceptions
                continue # Skip to next result if there was an error in one task

            try:
                result = json.loads(result_raw) # Parse JSON here, inside the loop processing results
                if result.get("success"):
                    for _disease_data in result.get("top_results", []): # Safely access top_results
                        for name, description_data in _disease_data.items():
                            if isinstance(description_data, dict) and "summary" in description_data: # Robust check for structure
                                main_results[name] = description_data["summary"]
                                # Update cache after successful processing
                                # self.scraper_cache[name] = result_raw # Store the raw JSON string in cache
                            # else:
                            #     logger.warning(f"Unexpected data structure in disease description: {description_data}")
                # else:
                #     logger.warning(f"Scraper tool reported failure: {result.get('error', 'No error message provided')}") # Log scraper tool failures

            except json.JSONDecodeError as e:
                # logger.error(f"JSONDecodeError processing result: {e}. Raw result: {result_raw}", exc_info=True) # Log JSON decode errors
                raise e
            except Exception as e:
                # logger.error(f"Unexpected error processing scraper result: {e}. Raw result: {result_raw}", exc_info=True) # Catch any other processing errors
                raise e

        try:
            final_diagnosis_list = [f"For this Disease: {name}, The Description is: {summary}" for name, summary in main_results.items()]
            disease_info = " ".join(final_diagnosis_list)
            patient_info = state.get("Patient_strucutred_info", {}) # Safely access Patient_strucutred_info

            response = await self.generate_structured_response( # Use the passed in function
                    DD_PROMPT,
                    DDSchema,
                    patient_demographics = patient_info.patient_demographics,
                    chief_complaints = patient_info.chief_complaints,
                    present_illness_history = patient_info.present_illness_history,
                    past_medical_history = patient_info.past_medical_history,
                    family_history = patient_info.family_history,
                    social_history= patient_info.social_history,
                    medications = patient_info.medications,
                    allergies = patient_info.allergies,
                    review_of_systems= patient_info.review_of_systems,
                    disease_info = disease_info
                )

            dd_results = []
            if response:
                dd_results = response.Diagnosis_List # Safely access Diagnosis_List
                    # logger.info(f"Number of DDs from LLM: {len(dd_results)}")
                state["Final_dd_list"]= dd_results
                # else:
                #      logger.warning("LLM response was empty.")

                state["Disease_Stored_Info"] = main_results
                return state
            else:
                # logger.warning("generate_structured_response function not provided. Skipping LLM interaction.")
                state["Disease_Stored_Info"] = main_results
                return state


        except Exception as e:
            error_message = f"Problem getting response from LLM: {e}"
            # logger.error(error_message, exc_info=True) # Log LLM response errors
            raise RuntimeError(error_message) from e # Re-raise with context


    
    def router_Thinker_node(self, state:AgentState):
        
        patient_allergies = state["Patient_strucutred_info"].allergies
        if patient_allergies and patient_allergies.lower() not in ["unknow","none","not mentioned",""]:
            return ["di_tool","test_tool"]
        return "test_tool"
        
    async def di_node(self, state: AgentState) -> AgentState:
        """Drug interaction node that checks for potenv tial interactions with current medications."""
    
        patient_allergies = state["Patient_strucutred_info"].allergies
        if patient_allergies and patient_allergies.lower() not in ["unknow","none","not mentioned",""]:
            pass
        
    async def get_tests(self, stored_info ,patient_info ,ddlist :list[DD_Structure]):
        
        disease1, disease2 = ddlist[0],ddlist[1]
        text = f"#Disease 1 is : {disease1.name} , #Disease_Description:{stored_info[disease1.name]} , #Thought : {disease1.rationale} \n #Disease 2 is : {disease2.name}, #Disease_Description:{stored_info[disease2.name]}, #Thoughts:{disease2.rationale}"
        try:
            response = await self.generate_structured_response(TEST_PROMPT, TestSchema, thought = text, patient_case = patient_info)
            if response:
                return  response.Test_List
            
            # print("Not able to get any answers .........")
        except Exception as e:
                raise RuntimeError(f"There was some error while getting tests : {e}")
            
    async def test_node(self, state: dict) -> dict:
        """
        Asynchronously retrieves recommended tests for differential diagnoses, optimized for production.

        - Asynchronous execution for parallel test retrieval.
        - Caching of test results to minimize redundant calls.
        - Robust error handling and logging.
        - Input validation and safe data access.
        - Clearer handling of DD pairs and potential odd-length lists.

        Args:
            state (dict): The agent state dictionary containing 'Final_dd_list', 'Disease_Stored_Info', and 'Patient_strucutred_info'.

        Returns:
            dict: The updated agent state dictionary with test results added to 'Tests'.
        """
        start_time = time.time()
        dd_list = state["Final_dd_list"]
        stored_info = state["Disease_Stored_Info"]
        patient_info = state["Patient_strucutred_info"]

        # if not dd_list:
        #     logger.info("Final_dd_list is empty. No tests to retrieve.")
        #     return state

        # if not isinstance(dd_list, list):
        #     logger.error(f"Expected 'Final_dd_list' to be a list, but got: {type(dd_list)}. Skipping test retrieval.")
        #     return state

        # if not stored_info:
        #     logger.warning("Disease_Stored_Info is empty. Tests retrieval might be limited.")
        # if not patient_info:
        #     logger.warning("Patient_strucutred_info is empty. Tests retrieval might be limited.")

        futures = []
        dd_pairs = list(zip(dd_list[::2], dd_list[1::2]))

        # Process pairs
        for d1, d2 in dd_pairs:
            # diagnosis_pair = tuple(sorted([d1, d2]))
            # cache_key = (diagnosis_pair, hash(json.dumps(patient_info, sort_keys=True)) if patient_info else None, hash(json.dumps(stored_info, sort_keys=True)) if stored_info else None)

            # cached_tests = self.tests_cache.get(cache_key)
            # if cached_tests:
            #     logger.info(f"Cache hit for DD pair: {diagnosis_pair}. Using cached test results.")
            #     futures.append(asyncio.to_thread(lambda res=cached_tests: res))
            # else:
            #     logger.info(f"Cache miss for DD pair: {diagnosis_pair}. Fetching tests...")
            #     if self.get_tests:
            futures.append(self.get_tests(stored_info, patient_info, [d1, d2]))
                # else:
                #     logger.error("get_tests function is not properly initialized in TestNode.")

        # Handle the case of a single leftover item if dd_list has odd length
        if len(dd_list) % 2 != 0:
            last_dd = dd_list[-1]
            # cache_key_single = (last_dd, hash(json.dumps(patient_info, sort_keys=True)) if patient_info else None, hash(json.dumps(stored_info, sort_keys=True)) if stored_info else None) # Different cache key for single disease
            # cached_tests_single = self.tests_cache.get(cache_key_single)
            # if cached_tests_single:
            #     logger.info(f"Cache hit for single DD: {last_dd}. Using cached test results.")
            #     futures.append(asyncio.to_thread(lambda res=cached_tests_single: res))
            # else:
            #     logger.info(f"Cache miss for single DD: {last_dd}. Fetching tests...")
            #     if self.get_tests:
            futures.append(self.get_tests(stored_info, patient_info, [last_dd])) # Call get_tests with a list of a single disease
                # else:
                #     logger.error("get_tests function is not properly initialized in TestNode.")

        all_tests = []
        if futures:
            try:
                results = await asyncio.gather(*futures, return_exceptions=True)
                pair_index = 0 # Keep track of index for pair processing
                for index, result in enumerate(results):
                    if isinstance(result, Exception):
                        # logger.error(f"Exception during test retrieval: {result}", exc_info=True)
                        continue

                    if isinstance(result, list):
                        all_tests.extend(result)

                        # Caching logic - now needs to handle both pairs and singles
                        # if index < len(dd_pairs): # Processing results for pairs
                        #     diagnosis_pair = dd_pairs[pair_index]
                            # diagnosis_pair_key = tuple(sorted([diagnosis_pair[0], diagnosis_pair[1]]))
                            # cache_key = (diagnosis_pair_key, hash(json.dumps(patient_info, sort_keys=True)) if patient_info else None, hash(json.dumps(stored_info, sort_keys=True)) if stored_info else None)
                            # self.tests_cache[cache_key] = result
                            # pair_index += 1 # Increment pair index
                    #     elif len(dd_list) % 2 != 0: # Processing result for single last item
                    #         last_dd = dd_list[-1]
                    #         cache_key_single = (last_dd, hash(json.dumps(patient_info, sort_keys=True)) if patient_info else None, hash(json.dumps(stored_info, sort_keys=True)) if stored_info else None)
                    #         self.tests_cache[cache_key_single] = result # Cache for single disease
                    # else:
                    #     logger.warning(f"Unexpected result type from get_tests: {type(result)}. Expected a list of tests.")

            except Exception as e:
                error_message = f"Error during asyncio.gather while fetching tests: {e}"
                # logger.error(error_message, exc_info=True)
                raise RuntimeError(error_message) from e

        # logger.info(f"Time taken to get tests results: {time.time() - start_time:.2f} seconds")
        # logger.info(f"Total number of tests retrieved: {len(all_tests)}")

        sorted_tests= defaultdict(list)
        for test in all_tests:
            sorted_tests[test.disease].append(test)
                
        state["Tests"] = sorted_tests
        
        return state
        

    async def get_partial_results(self, disease_dict :dict[str,any], patient_info):

        # print("inside the partial function")
        text = ""
        # Access disease_dict["tests"] once outside the loop if it's intended to be the same for all diseases in this call
        disease_tests_list = disease_dict.get("tests", []) # Use .get() to avoid KeyError if "tests" is missing, default to empty list

        for disease_name, disease_info in disease_dict.items():
            if disease_name == "tests": # Skip processing if the key is "tests" and not a disease name
                continue

            # Ensure disease_tests_list is used here instead of repeatedly accessing disease_dict["tests"]
            disease_tests = [
                f"-Test Name : {test.test_name},-Test Puprose : {test.purpose} -Test rationale :{test.rationale}, -Test Findings : {test.findings}"
                for test in disease_tests_list # Use the pre-fetched list
            ]
            tests = " ".join(disease_tests)
            _format = f"""##The Disease is :{disease_name},"
                                ->Disease Description: {disease_info["description"]},
                                ->Disease Rationale : {disease_info["rationale"]},
                                ->Disease Tests: {tests}"""
                            
            text += "\n\n" + _format

        try:
            response = await self.generate_structured_response(FINAL_PROMPT, FinalStructure, patient_info = patient_info, differential_diagnoses = text)
      
            return response.response
        except Exception as e:
            raise e
        
    async def validator_node(self, state: AgentState) -> AgentState:
        """Validation node that checks the consistency of diagnoses with patient history."""
        
        patient_info = state["Patient_strucutred_info"]
        dd_list = state["Final_dd_list"]
        disease_info = state["Disease_Stored_Info"]
        tests_list = state["Tests"]
        strucutred_info = {}
        try:
            for dd in dd_list:
                dd_name = dd.name # Cache dd.name once if it's accessed multiple times within the loop (minor optimization)
                strucutred_info[dd_name] = {
                    "rationale" : dd.rationale,
                    "description" : disease_info.get(dd_name), # Use .get() for potential missing keys, returns None if not found
                    "tests" : tests_list.get(dd_name)       # Use .get() for potential missing keys, returns None if not found
                }
        except KeyError as e: # Catch KeyError explicitly and assign it to 'e' to use in the print statement
            print(f"There was key error: {e}") # Corrected print statement to include the exception object 'e'
            raise
        
        # Calculate split index once
        # split_index = len(dd_list) // 2
        
        # Create futures directly, slightly more efficient list comprehension
        # futures = [
        #     self.get_partial_results({dd.name: strucutred_info[dd.name] for dd in dd_list_slice}, patient_info) # Construct disease_dict for each slice
        #     for dd_list_slice in [dd_list[:split_index], dd_list[split_index:]]
        # ]
        try:
            results = await self.get_partial_results(strucutred_info, patient_info)
            # state["Results"] = [val for result in gatherd_results for val in result]
            # print(gatherd_results)
            state["Results"] = results
            return state
        except Exception as e:
            print(e)
            raise e
        
        
    
    